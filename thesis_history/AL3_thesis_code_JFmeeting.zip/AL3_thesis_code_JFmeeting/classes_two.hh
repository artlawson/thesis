#ifndef __CLASSES_TWO_
#define __CLASSES_TWO_

#include <string>
#include <chrono>
#include <ratio>
#include <utility>
#include <vector>
#include <memory>
#include <set>
#include <unordered_map>
#include <queue>

#include <iostream>

//Trie object
class Trie{
    public:
        std::string name;
        std::vector<std::shared_ptr<Trie> > children;
        int n; //number of verticies in node
        std::vector<bool> adj;
        bool is_Graph;
        int num_id;
        std::vector<std::shared_ptr<Trie> > sisters; //prob don't need this anymore
};

class WorkUnit{
public:
    int depth; //D
    std::vector<int> v_used; //
    bool waiting_for_work;
    int p_id;
    std::shared_ptr<Trie> current_node;
    bool received_work_request;
    std::vector<std::shared_ptr<Trie> > explored_nodes; //N (nodes)
    //keep unexplored verts a set bc it avoids repeats
    std::unordered_map<int, std::set<int> > unexplored_verts; //Ui (verticies) maps depth to unexplored verticies
    WorkUnit();
    WorkUnit(int dd, std::vector<int> vv_used, std::vector<int> verts_left);
    bool is_empty();
    void mini_update(std::vector<int> verts_left);
    void divide_work(WorkUnit* w2);
};

class Vertex{
    public:
        int id;
};

class Graph { //currently storing globals in graph object
    public:
        int n; //number of verticies
        int P; //number of processors
        int TIME_THRESHOLD;
        bool FINISHED;
        std::unordered_map<std::string, std::set<std::vector<int> > > GDD; //keep counts

        std::__1::chrono::time_point<
            std::__1::chrono::steady_clock, std::__1::chrono::duration<
            long long, std::__1::ratio<1, 1000000000> > > LAST_CHECK; 
        std::queue<WorkUnit*> WORK_REQUESTS;
        std::unordered_map<int, std::set<int> > node_map; //verify later if we need this
        std::unordered_map<int, Vertex> verticies;
        std::set<std::pair<int,int> > edge_set;
        std::vector<std::vector<bool> > adj; 
     
};

#endif
