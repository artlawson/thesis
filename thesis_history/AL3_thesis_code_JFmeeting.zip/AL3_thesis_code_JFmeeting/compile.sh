
g++ -std=c++17 -lpthread -o p_main *.cpp
