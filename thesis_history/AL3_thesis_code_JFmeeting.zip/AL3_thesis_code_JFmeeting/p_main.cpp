//p_main
//gcc -lstdc++ -std=c++17  <file>
#include <iostream>
#include <chrono>
#include <iostream>
#include <string>
#include <memory>
#include <thread>
#include "file_reader_two.hh"
#include "classes_two.hh"
#include "worku.hh"

int main()
{
    //initialize
    std::cout<< "-------------------initializing data----------------" << std::endl;
   
    std::string file_path = "../txt/ca-AstroPh.txt";
    Graph G = create_graph(file_path);//defined in file_reader_two
    std::cout<< "Graph created\n" <<"There are " << G.edge_set.size() << " edges and " << G.verticies.size() << " verticies!"<< std::endl;

    //starting program
    std::cout<< "Creating G-trie" <<std::endl;
    std::shared_ptr<Trie> root = create_trie();//defined in file_reader_two
    std::cout<<"Trie initiation komplete!"<<std::endl;
    /*later make globals
    GDD
    G

    */
   
    G.P = 2;
    G.TIME_THRESHOLD = 420; //start with high number, update accordingly
    G.LAST_CHECK = std::chrono::high_resolution_clock::now();
    std::vector<std::thread> threads;


    std::cout<< "\n-------------------Starting  Program!----------------" << std::endl;
    auto start = std::chrono::high_resolution_clock::now();

    for (int i = 0; i < G.P; i++){
        //this is where meat of Parallel Count would happen
        //auto lm = [triangle_sub, star_sub,&node_map]{ t_trianlge(triangle_sub,star_sub, node_map);}; //t_triangle
        auto lm = [i ,root,&G]{ parallel_count(i,root, G);}; //t_triangle
        

        threads.push_back(std::thread{lm}); 
    }

    // Wait for each to complete
    std::cout<<"running on " << threads.size()<< " threads" <<std::endl;
    for (std::thread& t : threads) {
        //could print time of each thread finishing
        t.join();
    }
    auto stop = std::chrono::high_resolution_clock::now();
    auto duration = std::chrono::duration_cast<std::chrono::seconds>(stop - start);
    auto minutes = duration.count() / 60;
    auto seconds = duration.count() % 60;
    auto hours = minutes / 60;

    std::cout<< "This operation took \n" << duration.count() << " seconds"
    << "\nor "<<hours << "hours, " << minutes<< " minutes and " << seconds << " seconds" <<std::endl;

    std::cout<<"\n ------------------Here are the results--------------"<<std::endl;
    
    for (auto kv : G.GDD){
        std::string key = kv.first;
        int value = kv.second.size();
        
        std::cout<<value <<" " <<key << "s" <<std::endl;
    }
    //send an email to confirm program termination
    //int status;
    //status = system(R"(echo "your thesis code has terminated execution!" | mail -s "Thesis Execution Complete" "artlawson318@gmail.com")");

    return 318;
} 
