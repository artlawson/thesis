//classes
// g++ -std=c++17 classes_two.cpp
#include <string>
#include <chrono>
#include <ratio>
#include <utility>
#include <vector>
#include <memory>
#include <set>
#include <unordered_map>
#include <queue>
#include "classes_two.hh"


WorkUnit::WorkUnit() : WorkUnit{0, std::vector<int> (), std::vector<int>()} { }

WorkUnit::WorkUnit(int dd, std::vector<int> vv_used, std::vector<int> verts_left) :
  depth{dd},
  v_used{vv_used},
  p_id{0},
  current_node{nullptr},
  received_work_request{false}
{
    //constructor for work unit 
    //expected call from Parallel_match
    for (int i : verts_left){
        unexplored_verts[dd].insert(verts_left[i]);
    }
}

//empty check, if there are no verticies left to explore
//then W is considered empty and needs more work
bool WorkUnit::is_empty(){
    for (auto kv : unexplored_verts){
        if (!kv.second.empty()){
            return false;
        }
    }
    return true;
}

void WorkUnit::mini_update(std::vector<int> verts_left = std::vector<int>()){// int dd, std::vector<int> vv_used, )
    /*
    if (depth < dd){
    depth = dd; //only want to override depth if it went further
    }
    if (v_used.size() < vv_used.size()){
    v_used = vv_used;
    }
    */
    for (int i : verts_left){
        unexplored_verts[depth].insert(verts_left[i]);
    }
}


//takes a work unit as an argument so we can
//just put work units in work queue
void WorkUnit::divide_work(WorkUnit* w2){ //relatively done, could  be optimized
    w2->depth = depth;
    w2->explored_nodes = explored_nodes;
    w2->v_used = v_used;
            
    //here is where check for "is it worth the extra headache to split and send" would go
    for (int i = 1; i<= depth; i++){ //need to double check if depth is 0-3 or 1-4
        //cut in half and resize
        int x = unexplored_verts[i].size();
	if (x > 0){
	  //puts 2nd half of w1's list into w2's
	    std::set<int>::iterator it = unexplored_verts[i].begin();
	    std::advance(it, (x/2));
	    w2->unexplored_verts[i].insert(std::make_move_iterator(it),
					   std::make_move_iterator(unexplored_verts[i].end()));
	    //removes those elements from w1's
	    unexplored_verts[i].erase(it, unexplored_verts[i].end());
	}
                
    }
    //have some call here that would signal the new data is ready and whatever barrier we used can be lifted
    w2->waiting_for_work = false; //boom^
}

