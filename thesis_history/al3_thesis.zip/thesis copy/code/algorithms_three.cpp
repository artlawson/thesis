//algorithms 3
#include <iostream>
#include <vector>
#include <string>
#include <filesystem> //requires c++17
#include <algorithm>
#include <map>
#include "classes_two.cpp"



void candidates_creator(std::vector<int> &cand, std::vector<int> &v_used, Graph G){
    if (v_used.empty()){
        for (int v = 0; v < G.n; v++){
            cand.push_back(v);
        }
    }
    else{
        std::vector<int> conn;
        for (int vp : v_used){
            conn.insert(conn.end(),G.node_map[vp].begin(),G.node_map[vp].end());
        }

        int m_val = G.verticies.size();
        int m;

        for (int vp : conn){
            if (G.node_map[vp].size() < m_val){
                m = vp;
                m_val = G.node_map[vp].size();
            }
        }
        
        for (int vp : G.node_map[m]){
    
            if (std::find(v_used.begin(),v_used.end(),vp) == v_used.end()){
                cand.push_back(vp);
            }
    
        }    
    }
}

bool check_connections(int vp, std::vector<int> &v_used, Graph &G, std::shared_ptr<Trie> T){
    //finish here
    for (int i = 0; i < v_used.size(); i++){ // Jim says "Helper function (bool) for 59-75 -check-connections"
        //checking that connections in adj match
        //expected connections of Trie
        if (T->adj[i] == true){ //this needs to be tightened up
            if (!G.adj[v_used[i]][vp]){ //This is currently going to overcount, but we can fix that later
                return false;
            }
        }
    }
    return true;
}


std::vector<int> Matching_verticies(std::shared_ptr<Trie> T,Graph &G, std::vector<int> &v_used){ //Jim says "using sub-functions for this to make it more readable"
    std::vector<int> cand, cond, verticies;
    //populate candidates
    candidates_creator(cand,v_used, G);
    //check candidates connections to current path in v_used

    for (int vp : cand){
        if (check_connections(vp, v_used, G,T)){
            verticies.push_back(vp);
        }
    }
    
    return verticies;
}

void Match(std::shared_ptr<Trie> T, Graph &G, std::vector<int> v_used,
    std::unordered_map<std::string, std::set<std::vector<int> > > &GDD){
    std::vector<int> V = Matching_verticies(T, G ,v_used); //Matching_vert returning empty array for all edges
    
    //currently, V is 0 for all of size two, hmmm
    for (int lil_vert : V){
        v_used.push_back(lil_vert);
        if (T->is_Graph){ 
            //can have Trie.type = triangle, etc
            GDD[T->name].insert(v_used);
        }
        for (std::shared_ptr<Trie> c : T->children){
            
            Match(c,G,v_used, GDD);
        }

        v_used.pop_back();
    }     
}

void GtrieMatch(std::shared_ptr<Trie> T, Graph &G,
    std::unordered_map<std::string, std::set<std::vector<int> > > &GDD ){
    //currently not getting children for node case to node ca
    for (std::shared_ptr<Trie> c : T->children){
        std::vector<int> v_used;
        Match(c,G, v_used,GDD);
    }
    
}
