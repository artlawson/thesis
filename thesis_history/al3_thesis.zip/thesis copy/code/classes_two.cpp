//classes
// g++ -std=c++17 classes_two.cpp
#include <iostream>
#include <vector>
#include <set>
#include <map>
#include <unordered_map>


class Vertex{
    public:
        int id;

};

class Graph {
    public:
        int n; //number of verticies
        //std::vector<Vertex> verticies;
        std::unordered_map<int, std::set<int> > node_map;
        std::unordered_map<int, Vertex> verticies;
        std::set<std::pair<int,int> > edge_set;
        std::vector<std::vector<bool> > adj; //vert.id   
     
};

//Trie object
class Trie{
    public:
        std::string name;
        std::vector<std::shared_ptr<Trie> > children;
        int n; //number of verticies in node
        std::vector<bool> adj;
        bool is_Graph;
};





